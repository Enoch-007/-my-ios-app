#!/bin/bash

echo "🔍 Checking for UUID collisions in Xcode project..."

# Check if project.pbxproj exists
if [ ! -f "HearMark.xcodeproj/project.pbxproj" ]; then
    echo "❌ project.pbxproj not found"
    exit 1
fi

# Extract UUIDs from object definitions and check for actual duplicates
DUPLICATES=$(grep -E '^[[:space:]]*[0-9A-F]{8}[[:space:]]*[=/]' HearMark.xcodeproj/project.pbxproj | sed 's/^[[:space:]]*//' | cut -d' ' -f1 | sort | uniq -d)

if [ -z "$DUPLICATES" ]; then
    echo "✅ No UUID collisions found"
    exit 0
else
    echo "❌ UUID collisions detected:"
    echo "$DUPLICATES"
    echo "🔧 Run the following to fix collisions:"
    echo "   1. Open project in Xcode"
    echo "   2. Clean build folder (Cmd+Shift+K)"
    echo "   3. Regenerate project files if needed"
    exit 1
fi