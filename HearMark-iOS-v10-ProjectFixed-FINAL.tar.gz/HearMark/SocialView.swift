import SwiftUI

struct SocialView: View {
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @State private var selectedFilter = "All"
    private let filters = ["All", "Public", "Trending", "Following"]
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                filterSection
                
                if filteredBookmarks.isEmpty {
                    emptyStateView
                } else {
                    bookmarksList
                }
            }
            .navigationTitle("Social")
        }
    }
    
    private var filterSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(filters, id: \.self) { filter in
                    Button(action: { selectedFilter = filter }) {
                        Text(filter)
                            .font(.subheadline)
                            .fontWeight(.medium)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(selectedFilter == filter ? Color.blue : Color(.systemGray5))
                            .foregroundColor(selectedFilter == filter ? .white : .primary)
                            .clipShape(Capsule())
                    }
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical, 8)
    }
    
    private var bookmarksList: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                ForEach(filteredBookmarks) { bookmark in
                    SocialBookmarkCard(bookmark: bookmark)
                }
            }
            .padding()
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "person.2.circle")
                .font(.system(size: 60))
                .foregroundColor(.gray)
            
            VStack(spacing: 8) {
                Text("No Social Content")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Share your bookmarks publicly to see them here")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            Button(action: {}) {
                Text("Create Public Bookmark")
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
    
    private var filteredBookmarks: [Bookmark] {
        let publicBookmarks = bookmarkStore.bookmarks.filter { $0.isPublic }
        
        switch selectedFilter {
        case "Public":
            return publicBookmarks
        case "Trending":
            return publicBookmarks.sorted { $0.createdAt > $1.createdAt }
        case "Following":
            return [] // Would implement following logic
        default:
            return publicBookmarks
        }
    }
}

struct SocialBookmarkCard: View {
    let bookmark: Bookmark
    @State private var isLiked = false
    @State private var likeCount = Int.random(in: 0...50)
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header
            HStack {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 40, height: 40)
                    .overlay(
                        Text("U")
                            .font(.headline)
                            .foregroundColor(.white)
                    )
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("Anonymous User")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    Text(bookmark.createdAt, style: .relative)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                if let sourceApp = bookmark.sourceApp {
                    Text(sourceApp)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray5))
                        .clipShape(Capsule())
                }
            }
            
            // Content
            VStack(alignment: .leading, spacing: 8) {
                Text(bookmark.title)
                    .font(.headline)
                    .lineLimit(2)
                
                if !bookmark.transcript.isEmpty {
                    Text(bookmark.transcript)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(3)
                }
                
                HStack {
                    Text("\(Int(bookmark.duration)) seconds")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text("•")
                        .foregroundColor(.secondary)
                    
                    Text(bookmark.contentType.capitalized)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Actions
            HStack(spacing: 24) {
                Button(action: { toggleLike() }) {
                    HStack(spacing: 4) {
                        Image(systemName: isLiked ? "heart.fill" : "heart")
                            .foregroundColor(isLiked ? .red : .gray)
                        
                        Text("\(likeCount)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Button(action: {}) {
                    HStack(spacing: 4) {
                        Image(systemName: "message")
                            .foregroundColor(.gray)
                        
                        Text("Comment")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Button(action: {}) {
                    HStack(spacing: 4) {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.gray)
                        
                        Text("Share")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                if bookmark.audioURL != nil {
                    Button(action: {}) {
                        Image(systemName: "play.circle")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
    
    private func toggleLike() {
        withAnimation(.easeInOut(duration: 0.2)) {
            isLiked.toggle()
            likeCount += isLiked ? 1 : -1
        }
    }
}

#Preview {
    SocialView()
        .environmentObject(BookmarkStore())
}