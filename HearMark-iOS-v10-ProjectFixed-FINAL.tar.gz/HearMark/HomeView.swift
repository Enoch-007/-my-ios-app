import SwiftUI

struct HomeView: View {
    @EnvironmentObject var audioManager: AudioManager
    @EnvironmentObject var voiceCommandManager: VoiceCommandManager
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @State private var showingPermissionAlert = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                headerSection
                statusSection
                quickActionsSection
                recentBookmarksSection
                Spacer()
            }
            .padding()
            .navigationTitle("HearMark")
            .alert("Permissions Required", isPresented: $showingPermissionAlert) {
                Button("Settings") {
                    if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(settingsUrl)
                    }
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("Microphone and speech recognition permissions are required for background audio capture.")
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 8) {
            Image(systemName: "waveform.circle.fill")
                .font(.system(size: 60))
                .foregroundColor(.blue)
            
            Text("Background Audio Monitoring")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Say \"Hey Mark\" to bookmark audio")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }
    
    private var statusSection: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Monitoring Status")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        Circle()
                            .fill(audioManager.isBackgroundMonitoring ? Color.green : Color.red)
                            .frame(width: 8, height: 8)
                        
                        Text(audioManager.isBackgroundMonitoring ? "Active" : "Inactive")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text("Buffer Duration")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text("\(Int(audioManager.bufferDuration))s")
                        .font(.subheadline)
                        .fontWeight(.medium)
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            
            if audioManager.currentlyPlayingApp != "None" {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Currently Playing")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        Image(systemName: getAppIcon(for: audioManager.currentlyPlayingApp))
                            .foregroundColor(.blue)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(audioManager.currentlyPlayingApp)
                                .font(.subheadline)
                                .fontWeight(.medium)
                            
                            if !audioManager.backgroundAudioContent.isEmpty {
                                Text(audioManager.backgroundAudioContent)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .lineLimit(2)
                            }
                        }
                        
                        Spacer()
                    }
                }
                .padding()
                .background(Color(.systemBlue).opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
    }
    
    private var quickActionsSection: some View {
        VStack(spacing: 12) {
            Text("Quick Actions")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 12) {
                Button(action: toggleMonitoring) {
                    VStack(spacing: 8) {
                        Image(systemName: audioManager.isBackgroundMonitoring ? "stop.circle.fill" : "play.circle.fill")
                            .font(.title2)
                        
                        Text(audioManager.isBackgroundMonitoring ? "Stop" : "Start")
                            .font(.caption)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(audioManager.isBackgroundMonitoring ? Color.red : Color.green)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button(action: testVoiceCommand) {
                    VStack(spacing: 8) {
                        Image(systemName: "mic.circle.fill")
                            .font(.title2)
                        
                        Text("Test Voice")
                            .font(.caption)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button(action: showPermissions) {
                    VStack(spacing: 8) {
                        Image(systemName: "gear.circle.fill")
                            .font(.title2)
                        
                        Text("Settings")
                            .font(.caption)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.gray)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }
    
    private var recentBookmarksSection: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Recent Bookmarks")
                    .font(.headline)
                
                Spacer()
                
                Text("\(bookmarkStore.bookmarks.count)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if bookmarkStore.bookmarks.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "bookmark.circle")
                        .font(.title)
                        .foregroundColor(.gray)
                    
                    Text("No bookmarks yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("Say \"Hey Mark, book the last 30 seconds\" to create your first bookmark")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(Array(bookmarkStore.bookmarks.prefix(3))) { bookmark in
                        BookmarkRowView(bookmark: bookmark)
                    }
                }
            }
        }
    }
    
    private func getAppIcon(for appName: String) -> String {
        if appName.contains("Podcast") {
            return "podcast.circle.fill"
        } else if appName.contains("Music") || appName.contains("Spotify") {
            return "music.note.circle.fill"
        } else {
            return "speaker.wave.2.circle.fill"
        }
    }
    
    private func toggleMonitoring() {
        if audioManager.isBackgroundMonitoring {
            audioManager.stopBackgroundMonitoring()
        } else {
            audioManager.startBackgroundMonitoring()
        }
    }
    
    private func testVoiceCommand() {
        if voiceCommandManager.isEnabled {
            voiceCommandManager.startListening()
        } else {
            showingPermissionAlert = true
        }
    }
    
    private func showPermissions() {
        showingPermissionAlert = true
    }
}

struct BookmarkRowView: View {
    let bookmark: Bookmark
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(bookmark.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                
                HStack {
                    Text("\(Int(bookmark.duration))s")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if let sourceApp = bookmark.sourceApp {
                        Text("• \(sourceApp)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            Spacer()
            
            Image(systemName: "play.circle.fill")
                .foregroundColor(.blue)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}

#Preview {
    HomeView()
        .environmentObject(AudioManager())
        .environmentObject(VoiceCommandManager())
        .environmentObject(BookmarkStore())
}