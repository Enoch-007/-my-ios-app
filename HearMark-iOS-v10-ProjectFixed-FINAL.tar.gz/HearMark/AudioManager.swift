import Foundation
import AVFoundation
import Combine
import MediaPlayer

class AudioManager: NSObject, ObservableObject {
    @Published var isBackgroundMonitoring = false
    @Published var isCapturingAudio = false
    @Published var currentAudioLevel: Float = 0.0
    @Published var bufferDuration: TimeInterval = 0
    @Published var currentlyPlayingApp: String = "None"
    @Published var backgroundAudioContent: String = ""
    
    private var audioTapProcessor: AVAudioEngine?
    private var backgroundRecorder: AVAudioRecorder?
    private var rollingBuffer: CircularAudioBuffer?
    private var bufferTimer: Timer?
    
    private let audioSession = AVAudioSession.sharedInstance()
    private var captureURL: URL?
    
    // Background app detection
    private var currentMediaInfo: [String: Any] = [:]
    
    override init() {
        super.init()
        setupAudioSession()
    }
    
    private func setupAudioSession() {
        do {
            // Configure for background audio monitoring and capture
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .measurement, 
                                       options: [.mixWithOthers, .allowBluetooth, .defaultToSpeaker])
            try audioSession.setActive(true)
            
            // Request permissions for background audio monitoring
            audioSession.requestRecordPermission { [weak self] allowed in
                DispatchQueue.main.async {
                    if allowed {
                        self?.setupBackgroundMonitoring()
                    } else {
                        print("❌ Microphone permission required for background audio capture")
                    }
                }
            }
        } catch {
            print("❌ Failed to setup audio session: \(error)")
        }
    }
    
    private func setupBackgroundMonitoring() {
        // Initialize rolling buffer for continuous background capture
        rollingBuffer = CircularAudioBuffer(durationSeconds: 300) // 5-minute rolling buffer
        
        // Setup media player notifications for app detection
        setupMediaPlayerNotifications()
        
        // Start background monitoring
        startBackgroundMonitoring()
    }
    
    private func setupMediaPlayerNotifications() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(nowPlayingInfoChanged),
            name: .MPNowPlayingInfoDidChange,
            object: nil
        )
    }
    
    @objc private func nowPlayingInfoChanged() {
        DispatchQueue.main.async { [weak self] in
            self?.detectCurrentPlayingApp()
        }
    }
    
    private func detectCurrentPlayingApp() {
        let nowPlayingInfo = MPNowPlayingInfoCenter.default().nowPlayingInfo
        
        if let title = nowPlayingInfo?[MPMediaItemPropertyTitle] as? String,
           let artist = nowPlayingInfo?[MPMediaItemPropertyArtist] as? String {
            
            currentMediaInfo = nowPlayingInfo ?? [:]
            
            // Detect source app based on available metadata
            if nowPlayingInfo?[MPMediaItemPropertyPodcastTitle] != nil {
                currentlyPlayingApp = "Podcasts"
            } else if nowPlayingInfo?[MPMediaItemPropertyAlbumTitle] != nil {
                currentlyPlayingApp = "Music/Spotify"
            } else {
                currentlyPlayingApp = "Audio App"
            }
            
            backgroundAudioContent = "\(title) by \(artist)"
            
            print("🎵 Detected: \(currentlyPlayingApp) - \(backgroundAudioContent)")
        } else {
            currentlyPlayingApp = "None"
            backgroundAudioContent = ""
        }
    }
    
    func startBackgroundMonitoring() {
        guard !isBackgroundMonitoring else { return }
        
        do {
            // Setup continuous background audio capture
            let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileName = "background_buffer_\(Date().timeIntervalSince1970).m4a"
            captureURL = documentsPath.appendingPathComponent(fileName)
            
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 1, // Mono for efficiency
                AVEncoderAudioQualityKey: AVAudioQuality.medium.rawValue
            ]
            
            backgroundRecorder = try AVAudioRecorder(url: captureURL!, settings: settings)
            backgroundRecorder?.delegate = self
            backgroundRecorder?.isMeteringEnabled = true
            backgroundRecorder?.record()
            
            isBackgroundMonitoring = true
            bufferDuration = 0
            
            // Update buffer timer
            bufferTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
                self?.updateBufferStatus()
            }
            
            print("✅ Background audio monitoring started")
            
        } catch {
            print("❌ Failed to start background monitoring: \(error)")
        }
    }
    
    func captureLastNSeconds(_ seconds: Int = 30) -> URL? {
        guard isBackgroundMonitoring, let captureURL = captureURL else {
            print("❌ Background monitoring not active")
            return nil
        }
        
        // Stop current recording temporarily
        backgroundRecorder?.stop()
        
        // Create a new file for the extracted audio segment
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let segmentFileName = "bookmark_\(Date().timeIntervalSince1970).m4a"
        let segmentURL = documentsPath.appendingPathComponent(segmentFileName)
        
        // Extract the last N seconds from the rolling buffer
        if extractAudioSegment(from: captureURL, to: segmentURL, lastSeconds: TimeInterval(seconds)) {
            print("✅ Captured last \(seconds) seconds of background audio")
            
            // Restart background monitoring
            startBackgroundMonitoring()
            
            return segmentURL
        } else {
            print("❌ Failed to extract audio segment")
            // Restart background monitoring
            startBackgroundMonitoring()
            return nil
        }
    }
    
    private func extractAudioSegment(from sourceURL: URL, to destinationURL: URL, lastSeconds: TimeInterval) -> Bool {
        let asset = AVAsset(url: sourceURL)
        let duration = asset.duration.seconds
        
        guard duration >= lastSeconds else {
            print("❌ Available duration (\(duration)s) is less than requested (\(lastSeconds)s)")
            return false
        }
        
        let startTime = CMTime(seconds: duration - lastSeconds, preferredTimescale: 600)
        let endTime = CMTime(seconds: duration, preferredTimescale: 600)
        let exportRange = CMTimeRange(start: startTime, end: endTime)
        
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            print("❌ Could not create export session")
            return false
        }
        
        exportSession.outputURL = destinationURL
        exportSession.outputFileType = .m4a
        exportSession.timeRange = exportRange
        
        let semaphore = DispatchSemaphore(value: 0)
        var success = false
        
        exportSession.exportAsynchronously {
            success = exportSession.status == .completed
            if !success {
                print("❌ Export failed: \(exportSession.error?.localizedDescription ?? "Unknown error")")
            }
            semaphore.signal()
        }
        
        semaphore.wait()
        return success
    }
    
    func stopBackgroundMonitoring() {
        guard isBackgroundMonitoring else { return }
        
        backgroundRecorder?.stop()
        backgroundRecorder = nil
        
        bufferTimer?.invalidate()
        bufferTimer = nil
        
        isBackgroundMonitoring = false
        bufferDuration = 0
        
        print("🛑 Background audio monitoring stopped")
    }
    
    private func updateBufferStatus() {
        guard let recorder = backgroundRecorder, recorder.isRecording else { return }
        
        recorder.updateMeters()
        let averagePower = recorder.averagePower(forChannel: 0)
        
        DispatchQueue.main.async { [weak self] in
            self?.currentAudioLevel = averagePower
            self?.bufferDuration = recorder.currentTime
        }
    }
}

// MARK: - AVAudioRecorderDelegate
extension AudioManager: AVAudioRecorderDelegate {
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            print("✅ Background recording completed successfully")
        } else {
            print("❌ Background recording failed")
        }
    }
    
    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        if let error = error {
            print("❌ Background recording encode error: \(error)")
        }
    }
}

// MARK: - CircularAudioBuffer
class CircularAudioBuffer {
    private var buffer: Data
    private let maxSize: Int
    private var writePosition: Int = 0
    private var isFull: Bool = false
    
    init(durationSeconds: TimeInterval) {
        // Estimate buffer size based on audio format
        // 44.1kHz, 16-bit, mono = ~88KB per second
        maxSize = Int(durationSeconds * 88_000)
        buffer = Data(capacity: maxSize)
    }
    
    func append(_ data: Data) {
        let remainingSpace = maxSize - writePosition
        
        if data.count <= remainingSpace {
            buffer.append(data)
            writePosition += data.count
        } else {
            // Buffer is full, start overwriting from beginning
            let firstPart = data.prefix(remainingSpace)
            let secondPart = data.suffix(from: remainingSpace)
            
            buffer.append(firstPart)
            buffer = Data(secondPart)
            writePosition = secondPart.count
            isFull = true
        }
    }
    
    func getLastSeconds(_ seconds: TimeInterval) -> Data? {
        guard isFull || writePosition > 0 else { return nil }
        
        let bytesPerSecond = 88_000 // Approximation
        let requestedBytes = Int(seconds * Double(bytesPerSecond))
        let availableBytes = isFull ? maxSize : writePosition
        let actualBytes = min(requestedBytes, availableBytes)
        
        if actualBytes <= availableBytes {
            let startIndex = availableBytes - actualBytes
            return buffer.subdata(in: startIndex..<availableBytes)
        }
        
        return nil
    }
}