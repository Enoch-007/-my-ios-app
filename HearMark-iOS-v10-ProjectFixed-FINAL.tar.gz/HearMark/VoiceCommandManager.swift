import Foundation
import Speech
import AVFoundation
import Combine

class VoiceCommandManager: NSObject, ObservableObject {
    @Published var isEnabled = false
    @Published var isListening = false
    @Published var lastCommand: String?
    @Published var commandCount = 0
    @Published var detectedBackgroundCommand: String?
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    private var wakePhrase = "hey mark"
    private var isWakeWordDetected = false
    private var commandTimeout: Timer?
    private var audioManager: AudioManager?
    
    override init() {
        super.init()
        setupSpeechRecognition()
    }
    
    func setup(audioManager: AudioManager) {
        self.audioManager = audioManager
        requestPermissions()
    }
    
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { [weak self] authStatus in
            DispatchQueue.main.async {
                switch authStatus {
                case .authorized:
                    self?.isEnabled = true
                    self?.startListening()
                case .denied, .restricted, .notDetermined:
                    self?.isEnabled = false
                    print("Speech recognition not authorized")
                @unknown default:
                    self?.isEnabled = false
                }
            }
        }
        
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] allowed in
            DispatchQueue.main.async {
                if !allowed {
                    self?.isEnabled = false
                    print("Microphone permission denied")
                }
            }
        }
    }
    
    private func setupSpeechRecognition() {
        guard let speechRecognizer = speechRecognizer else {
            print("Speech recognizer not available")
            return
        }
        
        speechRecognizer.delegate = self
    }
    
    func startListening() {
        guard isEnabled && !isListening else { return }
        
        do {
            recognitionTask?.cancel()
            recognitionTask = nil
            
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else {
                print("❌ Unable to create recognition request")
                return
            }
            
            recognitionRequest.shouldReportPartialResults = true
            
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                self?.handleSpeechResult(result: result, error: error)
            }
            
            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
            
            isListening = true
            print("✅ Voice command listening started")
            
        } catch {
            print("❌ Failed to start voice recognition: \(error)")
        }
    }
    
    private func handleSpeechResult(result: SFSpeechRecognitionResult?, error: Error?) {
        if let error = error {
            print("❌ Speech recognition error: \(error)")
            return
        }
        
        guard let result = result else { return }
        
        let spokenText = result.bestTranscription.formattedString.lowercased()
        
        // Check for wake phrase
        if spokenText.contains(wakePhrase) {
            isWakeWordDetected = true
            lastCommand = spokenText
            
            // Process voice command for background audio capture
            processVoiceCommand(spokenText)
            
            // Reset after processing
            commandTimeout?.invalidate()
            commandTimeout = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { [weak self] _ in
                self?.isWakeWordDetected = false
            }
        }
    }
    
    private func processVoiceCommand(_ command: String) {
        commandCount += 1
        
        // Extract duration from command (default 30 seconds)
        var duration = 30
        
        if command.contains("last 10 seconds") || command.contains("10 seconds") {
            duration = 10
        } else if command.contains("last 60 seconds") || command.contains("minute") {
            duration = 60
        } else if command.contains("last 15 seconds") || command.contains("15 seconds") {
            duration = 15
        }
        
        // Capture background audio from the detected duration
        if let audioURL = audioManager?.captureLastNSeconds(duration) {
            // Create bookmark with background audio content
            let bookmark = Bookmark(
                title: generateBookmarkTitle(from: command, duration: duration),
                audioURL: audioURL,
                duration: TimeInterval(duration),
                contentType: detectContentType(),
                sourceApp: audioManager?.currentlyPlayingApp
            )
            
            // Notify about successful capture
            detectedBackgroundCommand = "Captured last \(duration) seconds from \(audioManager?.currentlyPlayingApp ?? "unknown app")"
            
            print("✅ Voice command processed: \(duration)s capture from \(audioManager?.currentlyPlayingApp ?? "unknown")")
        } else {
            detectedBackgroundCommand = "Failed to capture background audio"
            print("❌ Failed to capture background audio")
        }
    }
    
    private func generateBookmarkTitle(from command: String, duration: Int) -> String {
        let appName = audioManager?.currentlyPlayingApp ?? "Audio"
        let contentInfo = audioManager?.backgroundAudioContent ?? "Content"
        
        return "\(duration)s from \(appName): \(contentInfo)"
    }
    
    private func detectContentType() -> String {
        guard let app = audioManager?.currentlyPlayingApp else { return "other" }
        
        if app.contains("Podcast") {
            return "podcast"
        } else if app.contains("Music") || app.contains("Spotify") {
            return "music"
        } else {
            return "audiobook"
        }
    }
    
    func stopListening() {
        guard isListening else { return }
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil
        
        isListening = false
        print("🛑 Voice command listening stopped")
    }
}

// MARK: - SFSpeechRecognizerDelegate
extension VoiceCommandManager: SFSpeechRecognizerDelegate {
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        isEnabled = available
        
        if !available {
            print("⚠️ Speech recognizer became unavailable")
        }
    }
}