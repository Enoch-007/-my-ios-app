import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @EnvironmentObject var audioManager: AudioManager
    @EnvironmentObject var voiceCommandManager: VoiceCommandManager
    @EnvironmentObject var folderManager: FolderManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    profileHeaderSection
                    statsSection
                    settingsSection
                    aboutSection
                }
                .padding()
            }
            .navigationTitle("Profile")
        }
    }
    
    private var profileHeaderSection: some View {
        VStack(spacing: 16) {
            Circle()
                .fill(LinearGradient(
                    gradient: Gradient(colors: [.blue, .purple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .frame(width: 80, height: 80)
                .overlay(
                    Text("HM")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                )
            
            VStack(spacing: 4) {
                Text("HearMark User")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Audio bookmark enthusiast")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    private var statsSection: some View {
        VStack(spacing: 16) {
            Text("Your Stats")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 16) {
                StatCard(
                    title: "Bookmarks",
                    value: "\(bookmarkStore.bookmarks.count)",
                    icon: "bookmark.fill",
                    color: .blue
                )
                
                StatCard(
                    title: "Folders",
                    value: "\(folderManager.folders.count)",
                    icon: "folder.fill",
                    color: .green
                )
                
                StatCard(
                    title: "Voice Commands",
                    value: "\(voiceCommandManager.commandCount)",
                    icon: "mic.fill",
                    color: .orange
                )
            }
            
            HStack(spacing: 16) {
                StatCard(
                    title: "Total Duration",
                    value: formatTotalDuration(),
                    icon: "clock.fill",
                    color: .purple
                )
                
                StatCard(
                    title: "Buffer Time",
                    value: "\(Int(audioManager.bufferDuration))s",
                    icon: "waveform",
                    color: .red
                )
                
                StatCard(
                    title: "Public",
                    value: "\(bookmarkStore.bookmarks.filter { $0.isPublic }.count)",
                    icon: "person.2.fill",
                    color: .teal
                )
            }
        }
    }
    
    private var settingsSection: some View {
        VStack(spacing: 16) {
            Text("Settings")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(spacing: 0) {
                SettingsRow(
                    icon: "mic.circle.fill",
                    title: "Voice Commands",
                    subtitle: voiceCommandManager.isEnabled ? "Enabled" : "Disabled",
                    color: .blue
                ) {
                    // Toggle voice commands
                }
                
                Divider()
                    .padding(.leading, 44)
                
                SettingsRow(
                    icon: "waveform.circle.fill",
                    title: "Background Monitoring",
                    subtitle: audioManager.isBackgroundMonitoring ? "Active" : "Inactive",
                    color: .green
                ) {
                    // Toggle monitoring
                }
                
                Divider()
                    .padding(.leading, 44)
                
                SettingsRow(
                    icon: "bell.circle.fill",
                    title: "Notifications",
                    subtitle: "Configure alerts",
                    color: .orange
                ) {
                    // Open notifications settings
                }
                
                Divider()
                    .padding(.leading, 44)
                
                SettingsRow(
                    icon: "icloud.circle.fill",
                    title: "Data & Privacy",
                    subtitle: "Manage your data",
                    color: .cyan
                ) {
                    // Open privacy settings
                }
            }
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }
    
    private var aboutSection: some View {
        VStack(spacing: 16) {
            Text("About")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(spacing: 0) {
                SettingsRow(
                    icon: "questionmark.circle.fill",
                    title: "Help & Support",
                    subtitle: "Get help with HearMark",
                    color: .blue
                ) {
                    // Open help
                }
                
                Divider()
                    .padding(.leading, 44)
                
                SettingsRow(
                    icon: "doc.circle.fill",
                    title: "Privacy Policy",
                    subtitle: "Read our privacy policy",
                    color: .green
                ) {
                    // Open privacy policy
                }
                
                Divider()
                    .padding(.leading, 44)
                
                SettingsRow(
                    icon: "info.circle.fill",
                    title: "Version",
                    subtitle: "1.0.0 (Build 1)",
                    color: .gray
                ) {
                    // Show version info
                }
            }
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }
    
    private func formatTotalDuration() -> String {
        let totalSeconds = bookmarkStore.bookmarks.reduce(0) { $0 + $1.duration }
        let minutes = Int(totalSeconds) / 60
        let hours = minutes / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes % 60)m"
        } else {
            return "\(minutes)m"
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            Text(value)
                .font(.title3)
                .fontWeight(.bold)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                    .frame(width: 24)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    ProfileView()
        .environmentObject(BookmarkStore())
        .environmentObject(AudioManager())
        .environmentObject(VoiceCommandManager())
        .environmentObject(FolderManager())
}