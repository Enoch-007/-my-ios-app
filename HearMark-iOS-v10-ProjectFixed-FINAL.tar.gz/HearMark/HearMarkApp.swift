import SwiftUI
import AVFoundation

@main
struct HearMarkApp: App {
    @StateObject private var audioManager = AudioManager()
    @StateObject private var bookmarkStore = BookmarkStore()
    @StateObject private var voiceCommandManager = VoiceCommandManager()
    @StateObject private var folderManager = FolderManager()
    
    init() {
        setupAudioSession()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(audioManager)
                .environmentObject(bookmarkStore)
                .environmentObject(voiceCommandManager)
                .environmentObject(folderManager)
                .onAppear {
                    voiceCommandManager.setup(audioManager: audioManager)
                    bookmarkStore.loadBookmarks()
                    folderManager.loadFolders()
                }
        }
    }
    
    private func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetooth])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to configure audio session: \(error)")
        }
    }
}