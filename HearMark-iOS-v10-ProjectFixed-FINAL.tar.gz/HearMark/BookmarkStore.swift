import Foundation
import Combine

struct Bookmark: Identifiable, Codable {
    let id: UUID
    var title: String
    var transcript: String
    var audioURL: URL?
    var duration: TimeInterval
    var contentType: String
    var tags: [String]
    var folderId: UUID?
    var isPublic: Bool
    var createdAt: Date
    var updatedAt: Date
    
    var episodeName: String?
    var speakerName: String?
    var timestamp: String?
    var sourceApp: String?
    
    init(
        id: UUID = UUID(),
        title: String,
        transcript: String = "",
        audioURL: URL? = nil,
        duration: TimeInterval = 0,
        contentType: String = "other",
        tags: [String] = [],
        folderId: UUID? = nil,
        isPublic: Bool = false,
        episodeName: String? = nil,
        speakerName: String? = nil,
        timestamp: String? = nil,
        sourceApp: String? = nil
    ) {
        self.id = id
        self.title = title
        self.transcript = transcript
        self.audioURL = audioURL
        self.duration = duration
        self.contentType = contentType
        self.tags = tags
        self.folderId = folderId
        self.isPublic = isPublic
        self.episodeName = episodeName
        self.speakerName = speakerName
        self.timestamp = timestamp
        self.sourceApp = sourceApp
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}

class BookmarkStore: ObservableObject {
    @Published var bookmarks: [Bookmark] = []
    @Published var isLoading = false
    
    private let userDefaults = UserDefaults.standard
    private let bookmarksKey = "saved_bookmarks"
    
    init() {
        loadBookmarks()
    }
    
    func loadBookmarks() {
        isLoading = true
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            defer {
                DispatchQueue.main.async {
                    self?.isLoading = false
                }
            }
            
            guard let data = self?.userDefaults.data(forKey: self?.bookmarksKey ?? ""),
                  let bookmarks = try? JSONDecoder().decode([Bookmark].self, from: data) else {
                DispatchQueue.main.async {
                    self?.bookmarks = []
                }
                return
            }
            
            DispatchQueue.main.async {
                self?.bookmarks = bookmarks.sorted { $0.createdAt > $1.createdAt }
            }
        }
    }
    
    func saveBookmarks() {
        do {
            let data = try JSONEncoder().encode(bookmarks)
            userDefaults.set(data, forKey: bookmarksKey)
        } catch {
            print("❌ Failed to save bookmarks: \(error)")
        }
    }
    
    func addBookmark(_ bookmark: Bookmark) {
        bookmarks.insert(bookmark, at: 0)
        saveBookmarks()
    }
    
    func deleteBookmark(_ bookmark: Bookmark) {
        bookmarks.removeAll { $0.id == bookmark.id }
        saveBookmarks()
    }
    
    func updateBookmark(_ bookmark: Bookmark) {
        if let index = bookmarks.firstIndex(where: { $0.id == bookmark.id }) {
            var updatedBookmark = bookmark
            updatedBookmark.updatedAt = Date()
            bookmarks[index] = updatedBookmark
            saveBookmarks()
        }
    }
    
    func moveBookmark(_ bookmark: Bookmark, to folderId: UUID?) {
        if let index = bookmarks.firstIndex(where: { $0.id == bookmark.id }) {
            var updatedBookmark = bookmark
            updatedBookmark.folderId = folderId
            updatedBookmark.updatedAt = Date()
            bookmarks[index] = updatedBookmark
            saveBookmarks()
        }
    }
    
    func updateBookmarkTitle(_ bookmark: Bookmark, newTitle: String) {
        if let index = bookmarks.firstIndex(where: { $0.id == bookmark.id }) {
            var updatedBookmark = bookmark
            updatedBookmark.title = newTitle
            updatedBookmark.updatedAt = Date()
            bookmarks[index] = updatedBookmark
            saveBookmarks()
        }
    }
    
    func updateBookmarkTags(_ bookmark: Bookmark, newTags: [String]) {
        if let index = bookmarks.firstIndex(where: { $0.id == bookmark.id }) {
            var updatedBookmark = bookmark
            updatedBookmark.tags = newTags
            updatedBookmark.updatedAt = Date()
            bookmarks[index] = updatedBookmark
            saveBookmarks()
        }
    }
    
    func getBookmarks(in folder: UUID) -> [Bookmark] {
        return bookmarks.filter { $0.folderId == folder }
    }
    
    func getPublicBookmarks() -> [Bookmark] {
        return bookmarks.filter { $0.isPublic }
    }
    
    func searchBookmarks(query: String) -> [Bookmark] {
        let lowercasedQuery = query.lowercased()
        return bookmarks.filter { bookmark in
            bookmark.title.lowercased().contains(lowercasedQuery) ||
            bookmark.transcript.lowercased().contains(lowercasedQuery) ||
            bookmark.tags.contains { $0.lowercased().contains(lowercasedQuery) }
        }
    }
    
    func createBookmarkFromVoiceCommand(
        title: String,
        duration: TimeInterval = 30,
        contentType: String = "other",
        audioURL: URL? = nil,
        sourceApp: String? = nil
    ) -> Bookmark {
        let bookmark = Bookmark(
            title: title,
            audioURL: audioURL,
            duration: duration,
            contentType: contentType,
            sourceApp: sourceApp
        )
        
        addBookmark(bookmark)
        return bookmark
    }
    
    func exportBookmarks() -> Data? {
        do {
            return try JSONEncoder().encode(bookmarks)
        } catch {
            errorMessage = "Failed to export bookmarks: \(error.localizedDescription)"
            return nil
        }
    }
}