import Foundation
import Combine

struct Folder: Identifiable, Codable {
    let id: UUID
    var name: String
    var description: String
    var color: String
    var parentId: UUID?
    var createdAt: Date
    var updatedAt: Date
    
    init(
        id: UUID = UUID(),
        name: String,
        description: String = "",
        color: String = "#3B82F6",
        parentId: UUID? = nil,
        createdAt: Date = Date(),
        updatedAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.description = description
        self.color = color
        self.parentId = parentId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

class FolderManager: ObservableObject {
    @Published var folders: [Folder] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let userDefaults = UserDefaults.standard
    private let foldersKey = "stored_folders"
    
    init() {
        loadFolders()
        createDefaultFolders()
    }
    
    func loadFolders() {
        isLoading = true
        
        if let data = userDefaults.data(forKey: foldersKey),
           let decodedFolders = try? JSONDecoder().decode([Folder].self, from: data) {
            self.folders = decodedFolders
        }
        
        isLoading = false
    }
    
    func saveFolders() {
        do {
            let data = try JSONEncoder().encode(folders)
            userDefaults.set(data, forKey: foldersKey)
        } catch {
            errorMessage = "Failed to save folders: \(error.localizedDescription)"
        }
    }
    
    private func createDefaultFolders() {
        guard folders.isEmpty else { return }
        
        let defaultFolders = [
            Folder(
                name: "Podcasts",
                description: "Audio content from podcasts",
                color: "#3B82F6"
            ),
            Folder(
                name: "Audiobooks",
                description: "Content from audiobooks",
                color: "#10B981"
            ),
            Folder(
                name: "Music",
                description: "Music and song clips",
                color: "#F59E0B"
            ),
            Folder(
                name: "General",
                description: "Other audio content",
                color: "#6B7280"
            )
        ]
        
        folders = defaultFolders
        saveFolders()
    }
    
    func addFolder(_ folder: Folder) {
        folders.append(folder)
        saveFolders()
    }
    
    func addSubfolder(name: String, description: String, color: String, parentId: UUID) {
        let subfolder = Folder(
            name: name,
            description: description,
            color: color,
            parentId: parentId
        )
        folders.append(subfolder)
        saveFolders()
    }
    
    func updateFolder(_ folder: Folder) {
        if let index = folders.firstIndex(where: { $0.id == folder.id }) {
            var updatedFolder = folder
            updatedFolder.updatedAt = Date()
            folders[index] = updatedFolder
            saveFolders()
        }
    }
    
    func deleteFolder(_ folder: Folder) {
        // Also delete all subfolders
        let foldersToDelete = getAllSubfolders(of: folder.id)
        folders.removeAll { folderToDelete in
            foldersToDelete.contains(folderToDelete.id) || folderToDelete.id == folder.id
        }
        saveFolders()
    }
    
    func moveFolder(_ folder: Folder, to newParentId: UUID?) {
        if let index = folders.firstIndex(where: { $0.id == folder.id }) {
            var updatedFolder = folder
            updatedFolder.parentId = newParentId
            updatedFolder.updatedAt = Date()
            folders[index] = updatedFolder
            saveFolders()
        }
    }
    
    func getFolderByName(_ name: String) -> Folder? {
        return folders.first { $0.name.lowercased() == name.lowercased() }
    }
    
    func getFoldersByParent(_ parentId: UUID?) -> [Folder] {
        return folders.filter { $0.parentId == parentId }
    }
    
    func getRootFolders() -> [Folder] {
        return folders.filter { $0.parentId == nil }
    }
    
    func getSubfolders(of folder: Folder) -> [Folder] {
        return folders.filter { $0.parentId == folder.id }
    }
    
    func getAllSubfolders(of folderId: UUID) -> [Folder] {
        var allSubfolders: [Folder] = []
        let directSubfolders = folders.filter { $0.parentId == folderId }
        
        for subfolder in directSubfolders {
            allSubfolders.append(subfolder)
            allSubfolders.append(contentsOf: getAllSubfolders(of: subfolder.id))
        }
        
        return allSubfolders
    }
    
    func canMoveFolder(_ folder: Folder, to parentId: UUID?) -> Bool {
        // Prevent moving a folder into itself or its subfolder
        if let parentId = parentId {
            let allSubfolders = getAllSubfolders(of: folder.id)
            return parentId != folder.id && !allSubfolders.contains(where: { $0.id == parentId })
        }
        return true
    }
}