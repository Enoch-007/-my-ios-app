import SwiftUI

struct BookedView: View {
    @EnvironmentObject var folderManager: FolderManager
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @State private var searchText = ""
    @State private var selectedFilter: SearchFilter = .all
    @State private var showingCreateFolder = false
    
    enum SearchFilter: String, CaseIterable {
        case all = "All"
        case folders = "Folders"
        case bookmarks = "Bookmarks"
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search Header
                VStack(spacing: 12) {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        
                        TextField("Search folders and bookmarks...", text: $searchText)
                            .textFieldStyle(PlainTextFieldStyle())
                        
                        if !searchText.isEmpty {
                            Button(action: { searchText = "" }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    
                    if !searchText.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(SearchFilter.allCases, id: \.self) { filter in
                                    Button(action: { selectedFilter = filter }) {
                                        Text(filter.rawValue)
                                            .font(.subheadline)
                                            .fontWeight(.medium)
                                            .padding(.horizontal, 16)
                                            .padding(.vertical, 8)
                                            .background(selectedFilter == filter ? Color.blue : Color(.systemGray5))
                                            .foregroundColor(selectedFilter == filter ? .white : .primary)
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 8)
                
                // Content
                if searchText.isEmpty {
                    folderNavigationView
                } else {
                    searchResultsView
                }
            }
            .navigationTitle("Booked")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingCreateFolder = true }) {
                        Image(systemName: "folder.badge.plus")
                    }
                }
            }
        }
        .sheet(isPresented: $showingCreateFolder) {
            CreateFolderView()
        }
    }
    
    private var folderNavigationView: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                let folders = folderManager.folders
                if !folders.isEmpty {
                    foldersGridView(folders: folders)
                }
                
                let bookmarks = bookmarkStore.bookmarks
                if !bookmarks.isEmpty {
                    bookmarksListView(bookmarks: bookmarks)
                }
                
                if folders.isEmpty && bookmarks.isEmpty {
                    emptyStateView
                }
            }
            .padding()
        }
    }
    
    private var searchResultsView: some View {
        let filteredBookmarks = bookmarkStore.bookmarks.filter { bookmark in
            bookmark.title.lowercased().contains(searchText.lowercased()) ||
            bookmark.transcript.lowercased().contains(searchText.lowercased()) ||
            bookmark.tags.contains { $0.lowercased().contains(searchText.lowercased()) }
        }
        
        let filteredFolders = folderManager.folders.filter { folder in
            folder.name.lowercased().contains(searchText.lowercased()) ||
            folder.description.lowercased().contains(searchText.lowercased())
        }
        
        return ScrollView {
            LazyVStack(spacing: 16) {
                Text("Search Results for \"\(searchText)\"")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                if (selectedFilter == .all || selectedFilter == .folders) && !filteredFolders.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Folders")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        foldersGridView(folders: filteredFolders)
                    }
                }
                
                if (selectedFilter == .all || selectedFilter == .bookmarks) && !filteredBookmarks.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Bookmarks")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        bookmarksListView(bookmarks: filteredBookmarks)
                    }
                }
                
                if filteredFolders.isEmpty && filteredBookmarks.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "magnifyingglass")
                            .font(.largeTitle)
                            .foregroundColor(.gray)
                        
                        Text("No results found")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        Text("Try adjusting your search terms")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 40)
                }
            }
            .padding()
        }
    }
    
    private func foldersGridView(folders: [Folder]) -> some View {
        LazyVGrid(columns: [
            GridItem(.flexible()),
            GridItem(.flexible())
        ], spacing: 12) {
            ForEach(folders) { folder in
                FolderCardView(folder: folder)
                    .frame(height: 120)
            }
        }
    }
    
    private func bookmarksListView(bookmarks: [Bookmark]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Bookmarks")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)
            
            LazyVStack(spacing: 8) {
                ForEach(bookmarks) { bookmark in
                    BookmarkCardView(bookmark: bookmark)
                }
            }
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "folder.badge.plus")
                .font(.system(size: 64))
                .foregroundColor(.gray)
            
            VStack(spacing: 8) {
                Text("No Content Yet")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Create folders to organize your bookmarks")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            Button(action: { showingCreateFolder = true }) {
                HStack {
                    Image(systemName: "folder.badge.plus")
                    Text("Create First Folder")
                }
                .fontWeight(.medium)
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding(.vertical, 60)
    }
}

struct FolderCardView: View {
    let folder: Folder
    @EnvironmentObject var folderManager: FolderManager
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @State private var showingEditSheet = false
    @State private var showingAddSubfolder = false
    @State private var showingMoveSheet = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "folder.fill")
                    .font(.title2)
                    .foregroundColor(Color(hex: folder.color))
                
                Spacer()
                
                Menu {
                    Button(action: { showingAddSubfolder = true }) {
                        Label("Add Subfolder", systemImage: "folder.badge.plus")
                    }
                    
                    Button(action: { showingEditSheet = true }) {
                        Label("Edit Folder", systemImage: "pencil")
                    }
                    
                    Button(action: { showingMoveSheet = true }) {
                        Label("Move Folder", systemImage: "arrow.up.and.down.and.arrow.left.and.right")
                    }
                    
                    Divider()
                    
                    Button(role: .destructive, action: { deleteFolder() }) {
                        Label("Delete Folder", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .foregroundColor(.secondary)
                        .font(.caption)
                }
            }
            
            Text(folder.name)
                .font(.subheadline)
                .fontWeight(.medium)
                .lineLimit(1)
            
            if !folder.description.isEmpty {
                Text(folder.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            
            // Show subfolder count if any
            let subfolderCount = folderManager.getSubfolders(of: folder).count
            if subfolderCount > 0 {
                Text("\(subfolderCount) subfolders")
                    .font(.caption2)
                    .foregroundColor(Color(hex: folder.color))
                    .fontWeight(.medium)
            }
            
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .sheet(isPresented: $showingEditSheet) {
            EditFolderView(folder: folder)
        }
        .sheet(isPresented: $showingAddSubfolder) {
            CreateSubfolderView(parentFolder: folder)
        }
        .sheet(isPresented: $showingMoveSheet) {
            MoveFolderView(folder: folder)
        }
    }
    
    private func deleteFolder() {
        folderManager.deleteFolder(folder)
    }
}

struct BookmarkCardView: View {
    let bookmark: Bookmark
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @EnvironmentObject var folderManager: FolderManager
    @State private var showingEditSheet = false
    @State private var showingMoveSheet = false
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(bookmark.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                
                if !bookmark.transcript.isEmpty {
                    Text(bookmark.transcript)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
                
                HStack {
                    Text(bookmark.contentType.capitalized)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.blue.opacity(0.2))
                        .clipShape(Capsule())
                    
                    Text("\(Int(bookmark.duration))s")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                }
            }
            
            Spacer()
            
            HStack(spacing: 12) {
                Button(action: {}) {
                    Image(systemName: "play.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                }
                
                Menu {
                    Button(action: { showingEditSheet = true }) {
                        Label("Edit Bookmark", systemImage: "pencil")
                    }
                    
                    Button(action: { showingMoveSheet = true }) {
                        Label("Move to Folder", systemImage: "folder")
                    }
                    
                    Divider()
                    
                    Button(role: .destructive, action: { deleteBookmark() }) {
                        Label("Delete Bookmark", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .sheet(isPresented: $showingEditSheet) {
            EditBookmarkView(bookmark: bookmark)
        }
        .sheet(isPresented: $showingMoveSheet) {
            MoveBookmarkView(bookmark: bookmark)
        }
    }
    
    private func deleteBookmark() {
        bookmarkStore.deleteBookmark(bookmark)
    }
}

struct CreateFolderView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var folderManager: FolderManager
    @State private var folderName = ""
    @State private var folderDescription = ""
    @State private var selectedColor = "#3B82F6"
    
    let folderColors = [
        "#3B82F6", "#EF4444", "#10B981", "#F59E0B",
        "#8B5CF6", "#F97316", "#EC4899", "#6B7280"
    ]
    
    var body: some View {
        NavigationView {
            Form {
                Section("Folder Details") {
                    TextField("Folder Name", text: $folderName)
                    TextField("Description (optional)", text: $folderDescription, axis: .vertical)
                        .lineLimit(2...4)
                }
                
                Section("Color") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 12) {
                        ForEach(folderColors, id: \.self) { color in
                            Button(action: { selectedColor = color }) {
                                Circle()
                                    .fill(Color(hex: color))
                                    .frame(width: 40, height: 40)
                                    .overlay(
                                        Circle()
                                            .stroke(selectedColor == color ? Color.primary : Color.clear, lineWidth: 2)
                                    )
                            }
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("New Folder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Create") {
                        createFolder()
                    }
                    .disabled(folderName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
    
    private func createFolder() {
        let folder = Folder(
            name: folderName.trimmingCharacters(in: .whitespacesAndNewlines),
            description: folderDescription.trimmingCharacters(in: .whitespacesAndNewlines),
            color: selectedColor
        )
        
        folderManager.addFolder(folder)
        dismiss()
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - New Views for Editing and Management

struct EditFolderView: View {
    let folder: Folder
    @EnvironmentObject var folderManager: FolderManager
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var description: String
    @State private var selectedColor: String
    
    private let colors = [
        "#3B82F6", "#EF4444", "#10B981", "#F59E0B",
        "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"
    ]
    
    init(folder: Folder) {
        self.folder = folder
        self._name = State(initialValue: folder.name)
        self._description = State(initialValue: folder.description)
        self._selectedColor = State(initialValue: folder.color)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Folder Details")) {
                    TextField("Folder Name", text: $name)
                    TextField("Description (Optional)", text: $description, axis: .vertical)
                        .lineLimit(3)
                }
                
                Section(header: Text("Color")) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 12) {
                        ForEach(colors, id: \.self) { color in
                            Circle()
                                .fill(Color(hex: color))
                                .frame(width: 40, height: 40)
                                .overlay(
                                    Circle()
                                        .stroke(selectedColor == color ? Color.primary : Color.clear, lineWidth: 2)
                                )
                                .onTapGesture {
                                    selectedColor = color
                                }
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("Edit Folder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveChanges()
                    }
                    .disabled(name.isEmpty)
                }
            }
        }
    }
    
    private func saveChanges() {
        var updatedFolder = folder
        updatedFolder.name = name
        updatedFolder.description = description
        updatedFolder.color = selectedColor
        folderManager.updateFolder(updatedFolder)
        dismiss()
    }
}

struct CreateSubfolderView: View {
    let parentFolder: Folder
    @EnvironmentObject var folderManager: FolderManager
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var description = ""
    @State private var selectedColor: String
    
    private let colors = [
        "#3B82F6", "#EF4444", "#10B981", "#F59E0B",
        "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"
    ]
    
    init(parentFolder: Folder) {
        self.parentFolder = parentFolder
        self._selectedColor = State(initialValue: parentFolder.color)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Subfolder Details")) {
                    HStack {
                        Text("Parent:")
                        Spacer()
                        Text(parentFolder.name)
                            .foregroundColor(.secondary)
                    }
                    TextField("Subfolder Name", text: $name)
                    TextField("Description (Optional)", text: $description, axis: .vertical)
                        .lineLimit(3)
                }
                
                Section(header: Text("Color")) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 12) {
                        ForEach(colors, id: \.self) { color in
                            Circle()
                                .fill(Color(hex: color))
                                .frame(width: 40, height: 40)
                                .overlay(
                                    Circle()
                                        .stroke(selectedColor == color ? Color.primary : Color.clear, lineWidth: 2)
                                )
                                .onTapGesture {
                                    selectedColor = color
                                }
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("New Subfolder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Create") {
                        createSubfolder()
                    }
                    .disabled(name.isEmpty)
                }
            }
        }
    }
    
    private func createSubfolder() {
        folderManager.addSubfolder(
            name: name,
            description: description,
            color: selectedColor,
            parentId: parentFolder.id
        )
        dismiss()
    }
}

struct MoveFolderView: View {
    let folder: Folder
    @EnvironmentObject var folderManager: FolderManager
    @Environment(\.dismiss) private var dismiss
    @State private var selectedParentId: UUID?
    
    var availableFolders: [Folder] {
        return folderManager.folders.filter { availableFolder in
            folderManager.canMoveFolder(folder, to: availableFolder.id) && availableFolder.id != folder.id
        }
    }
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Move '\(folder.name)' to:")) {
                    HStack {
                        Image(systemName: "house")
                            .foregroundColor(.blue)
                        Text("Root Level")
                        Spacer()
                        if selectedParentId == nil {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedParentId = nil
                    }
                    
                    ForEach(availableFolders) { availableFolder in
                        HStack {
                            Image(systemName: "folder")
                                .foregroundColor(Color(hex: availableFolder.color))
                            Text(availableFolder.name)
                            Spacer()
                            if selectedParentId == availableFolder.id {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedParentId = availableFolder.id
                        }
                    }
                }
            }
            .navigationTitle("Move Folder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Move") {
                        moveFolder()
                    }
                }
            }
        }
    }
    
    private func moveFolder() {
        folderManager.moveFolder(folder, to: selectedParentId)
        dismiss()
    }
}

struct EditBookmarkView: View {
    let bookmark: Bookmark
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var tags: String
    
    init(bookmark: Bookmark) {
        self.bookmark = bookmark
        self._title = State(initialValue: bookmark.title)
        self._tags = State(initialValue: bookmark.tags.joined(separator: ", "))
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Bookmark Details")) {
                    TextField("Title", text: $title)
                    TextField("Tags (comma separated)", text: $tags)
                        .autocorrectionDisabled()
                }
                
                Section(header: Text("Content")) {
                    Text(bookmark.transcript.isEmpty ? "No transcript available" : bookmark.transcript)
                        .foregroundColor(bookmark.transcript.isEmpty ? .secondary : .primary)
                }
                
                Section(header: Text("Metadata")) {
                    HStack {
                        Text("Type:")
                        Spacer()
                        Text(bookmark.contentType.capitalized)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Duration:")
                        Spacer()
                        Text("\(Int(bookmark.duration)) seconds")
                            .foregroundColor(.secondary)
                    }
                    if let sourceApp = bookmark.sourceApp {
                        HStack {
                            Text("Source:")
                            Spacer()
                            Text(sourceApp)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Edit Bookmark")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveChanges()
                    }
                    .disabled(title.isEmpty)
                }
            }
        }
    }
    
    private func saveChanges() {
        bookmarkStore.updateBookmarkTitle(bookmark, newTitle: title)
        let newTags = tags.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        bookmarkStore.updateBookmarkTags(bookmark, newTags: newTags)
        dismiss()
    }
}

struct MoveBookmarkView: View {
    let bookmark: Bookmark
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @EnvironmentObject var folderManager: FolderManager
    @Environment(\.dismiss) private var dismiss
    @State private var selectedFolderId: UUID?
    
    init(bookmark: Bookmark) {
        self.bookmark = bookmark
        self._selectedFolderId = State(initialValue: bookmark.folderId)
    }
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Move '\(bookmark.title)' to:")) {
                    HStack {
                        Image(systemName: "house")
                            .foregroundColor(.blue)
                        Text("No Folder")
                        Spacer()
                        if selectedFolderId == nil {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedFolderId = nil
                    }
                    
                    ForEach(folderManager.folders) { folder in
                        HStack {
                            Image(systemName: "folder")
                                .foregroundColor(Color(hex: folder.color))
                            Text(folder.name)
                            Spacer()
                            if selectedFolderId == folder.id {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedFolderId = folder.id
                        }
                    }
                }
            }
            .navigationTitle("Move Bookmark")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Move") {
                        moveBookmark()
                    }
                }
            }
        }
    }
    
    private func moveBookmark() {
        bookmarkStore.moveBookmark(bookmark, to: selectedFolderId)
        dismiss()
    }
}

#Preview {
    BookedView()
        .environmentObject(FolderManager())
        .environmentObject(BookmarkStore())
}